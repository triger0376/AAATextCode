export default {
  text: "操作文本",
};
