export default {
    querAllData(){
        console.log(my.request)
    }
}